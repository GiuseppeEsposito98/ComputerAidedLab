# LABORATORY 1 - Single server queuing system simulation.

## REQUIREMENTS:
To run the script check that you have installed the package numpy in the current environment where you run the simulation beacuse it is used to run some random functions. 

## INSTRUCTION TO START:
To start the simulation with the default parameters (SIM_TIME = 30, mu = 0.1, lam = 0.95) just run the lab1.py file. 
If you want to try different simulation parameters change the values SIM_TIME, mu, lam.
