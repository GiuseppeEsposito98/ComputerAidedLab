import numpy as np

counter_lines = 0
counter_words = 0
distinct_words = set()
with open('commedia.txt') as f:
    lines = f.readlines()
    for line in lines:
        counter_lines = counter_lines +1
        words = line.split(' ')
        for word in words:
            counter_words = counter_words +1
            distinct_words.add(word)

print("counter lines: ", counter_lines)
print('counter words: ',counter_words)
print('counter distinct words: ', len(distinct_words))

